package ge.edu.btu.calculator.service;

public interface CalculatorService {
    int sum(int x, int y);
    double sum(double x, double y);
    double divide(int x, int y);
    double divide(double x, double y);
}
